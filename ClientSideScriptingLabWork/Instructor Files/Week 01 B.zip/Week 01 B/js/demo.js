// alert("This is annoying!");
console.log("JavaScript is working.");