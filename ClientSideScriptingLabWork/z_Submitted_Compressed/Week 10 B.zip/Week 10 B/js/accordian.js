$(document).ready(function () {

    $('#accordion').accordion({
        active: false,
        collapsible: true,
        icons: {
            header: 'ui-icon-circle-plus',
            activeHeader: 'ui-icon-circle-minus'
        }
    });



}); // end ready
