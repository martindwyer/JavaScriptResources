alert("This is an alert!");
console.log("JavaScript is working.");