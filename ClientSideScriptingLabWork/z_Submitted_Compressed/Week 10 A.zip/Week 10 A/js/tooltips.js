$(document).ready(function () {

    $('[title]').tooltip();

    $('#contact').tooltip({
        content: $('#contactInfo').html()
    });




}); // end ready
