// initialization code
var messageBox = document.getElementById("messageBox");
messageBox.innerHTML = "Press New Game to Begin"
var numGuessesBox = document.getElementById("numGuesses");
var numGuesses = 0;
var rankBox = document.getElementById("rank");
var rank = "Unkown";
var secretNumber = 0;
var gameInProgress = true;

function newGame() {
    // set up a new game

    // first, is a game already running?
    if(gameInProgress===true) {
        var checkQuit = confirm("Quit current game?")
        if(checkQuit===false) {
            return;
        }   
        
    rankBox.innerHTML = "Quitter";
        
    }  // either game wasn't running, or checkQuit was true
    
    
    // set up a new game
    // get a number from 1 to 100
    secretNumber= Math.floor((Math.random() * 100) + 1);
    
    // reset guesses to 0
    numGuesses = 0;
    numGuessesBox.innerHTML = numGuesses;
    messageBox.innerHTML = "Enter first guess!"
    
    // set gameInProgress to true
    gameInProgress = true;

    // Debugging line:
    console.log("secretNum =" + secretNumber);
    
    
}

function checkGuess() {
    If(gameInProgress == false) {
        alert("You need to start a game first!");
        document.getElementById("guessBox").value="";
    }
    var userGuess = document.getElementById("guessBox").value;
    console.log("User guessed: " + )
        
    // type 1 missing input
    if( userGuess == "") {
        alert("You must enter a guess!");
        return;
    }
    
    // type 2 input type mismatch wrong kind of number)
        if (userGuess%1 != 0) {
        alert("Enter only whole numbers!")
        return;
    }
    
    // type 
    if ( isNAN(userGuess)==true) {
        alert("You must enter a number!");
        return;
    }

    // type 3 input out of range
    if (user Guess < 1 || userGuess > 100) {
        alert("Your guess shoud be from 1 to 100!");
        return;
    }
    
    // if we got this far, the guess must be valid
    numGuesses = numGuesses + 1;
    numGuessesBox.innerHTML = numGuesses;
    document.getElementById("guessBox").value = "";
    
    // Is this correct?
    if(userGuess == secretNumber) {
        messageBox.innerHTML = "You win!!";
        gameInProgress = false;
        // code to rank the player
        if (numGuesses <= 3) {
            rankBox.innterHTML = "Genius!";
        }
        else if (numGuesses <= 5) {
            rankBox.innterHTML = "Good!";
            
        }
        else if (numGuesses <=10) {
            rankBox.innterHTML = "Average."
        }
        else if (numGuesses <= 15) {
            rankBox.innterHTML = "Fair";
        }
        else {
            rankBox.innterHTML = "Toddler";
        }    
    }
    else if (userGuess > secretNumber) {
        messageBox.innterHTML = "Too high! Try again.";   
    }
    else {
        messageBox.innterHTML = "Too low! Try again.";
    }
}

